<html>
	<head>
		<title>Web stranice autorizacija</title>
	</head>

	<style>
		#forma{
			width: 350px;
			margin: 20% auto 0;
			text-align: center;
			border-radius: 5px;
		}
	</style>

	<body>
		<div id="forma">

		<form action="" method="post">

			<input name="username" type="text" placeholder="Korisnički račun"><br>

			<input name="password" type="password" placeholder="Lozinka"><br>

			<input name="submit" type="submit" value=" Login ">

		</form>

		<?php
			$username="";
			$password="";

			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				
				$ans=$_POST;

				if (empty($ans["username"]))  {
						echo "<p>Korisnički račun nije unesen.</p>";
					
						}
				else if (empty($ans["password"]))  {
						echo "<p>Lozinka nije unesena.</p>";
					
						}
				else {
					$username= $ans["username"];
					$password= $ans["password"];
				
					provjera($username,$password);
				}
			}


			function provjera($username, $password) {
				

				$xml=simplexml_load_file("users.xml");
				
				
				foreach ($xml->korisnik as $usr) {
					$usrn = $usr->username;
					$usrp = $usr->password;
					$usrweb = $usr->web;
					if($usrn==$username){
						if($usrp == $password){
							echo
							"<form action='$usrweb'>
								<input type='submit' value='Vaš Website' class='button'/>
							</form>";
							return;
							}
						else{
							echo "<p>Netocna lozinka</p>";
							return;
							}
						}
					}
					
				echo "<p>Korisnik ne postoji.</p>";
				return;
			}
		?>
		</div>

	</body>
</html>